package org.hl7.fhir.utilities;

public interface FileNotifier {

  public void copyFile(String src, String dst);
  
}
